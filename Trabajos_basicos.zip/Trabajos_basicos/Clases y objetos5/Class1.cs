﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_y_objetos5
{
    internal static class Operaciones
    {
        public static double Suma(double v1, double v2)
        {
            return v1 + v2;
        
        }
        public static double Resta(double v1, double v2)
        {
            return v1 - v2;
        }
        public static double Multiplicación(double v1, double v2)
        {
            return v1 * v2;
        
        }
        public static double División(double v1, double v2)
        {
            return v1 / v2;
        }
    }
}
