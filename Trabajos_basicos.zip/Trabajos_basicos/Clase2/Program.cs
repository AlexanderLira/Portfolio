﻿using System;
namespace Practica0
{
    class CDeportista
    {
        //Atributos
        private string nombre, deporte;
       public string Nombre
        {
            
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
         public string Deporte
        {
            get
            {
                return deporte;
            }
            set
            {
                deporte = value;
            }
        }
            
        
        
        private double peso, altura;
        public double Peso
        {
            get
            {
                return peso;
            
            }
            set
            {
                peso = value;
            }
        }
        public double Altura
        {
            get
            {
                return altura;
            }
            set
            {
                altura = value;
            }
        }


        
        
        //Metodos
        public CDeportista()
        {
            
            //constructor sin parametros
            nombre = string.Empty;
            deporte = string.Empty;
            peso = 0.0;
            altura = 0.0;
            
        }
        public CDeportista(string n, string d, double p, double a)
        {
            //constructor con parametros
            nombre = n;
            deporte = d;
            peso = p;
            altura = a;
        }
        public CDeportista(CDeportista d)
        {
            //constructor copia
            this.nombre = d.nombre;
            this.deporte = d.deporte;
            this.peso = d.peso;
            this.altura = d.altura;
        }
        public void Leer_datos()
        {
            //lectura de los valores de atributos
            Console.Write("\n");
            Console.WriteLine("Datos de la persona:");
            Console.Write("Nombre del deportista: ");
            nombre = Console.ReadLine();
            Console.Write("Deporte: ");
            deporte = Console.ReadLine();
            Console.Write("Peso (lbr): ");
            peso = double.Parse(Console.ReadLine());
            Console.Write("Altura (cm): ");
            altura = double.Parse(Console.ReadLine());
        }
        public void Mostrar_datos()
        {
            //visualizacion de los valores de atributos
            Console.Write("\n");
            Console.WriteLine("Impresion de datos");
            Console.WriteLine("Nombre: {0} \t Deporte: {1}", nombre, deporte);
            Console.WriteLine("Peso: " + peso);
            Console.WriteLine("Altura: " + altura);
            Console.Write("\n");
        }
    }
    class Program
    {
        
            



        static void Main(string[] args)
        {
            CDeportista p1, p2, p3;
            p1 = new CDeportista("Luis", "futbol", 200, 170);
            p1.Mostrar_datos();
            
            //uso del constructor copia
            p2 = new CDeportista(p1);
            p2.Mostrar_datos();
            p3 = new CDeportista();
            p3.Leer_datos();
            p3.Mostrar_datos();
            Console.Write("\n");
        }
    }   
}
