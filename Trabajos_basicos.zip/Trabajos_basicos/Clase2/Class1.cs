﻿using Practica0;
using System;

namespace Practica1
{
    class CDeportista
    {
        //Atributos
        private string nombre, deporte;
        private double peso, altura;
        //Propiedades
        public string Nombre
        {

            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
        public string Deporte
        {
            get
            {
                return deporte;
            }
            set
            {
                deporte = value;
            }
        }
        public double Peso
        {
            get
            {
                return peso;

            }
            set
            {
                peso = value;
            }
        }
        public double Altura
        {
            get
            {
                return altura;
            }
            set
            {
                altura = value;
            }
        }
        //Metodos

    }
}
class program
{
    

    public static void main(string[] args)
    {
        
        Console.WriteLine("Cantidad de personas");
        Console.WriteLine("para ingresar datos...");
        int total = int.Parse(Console.ReadLine());
        CDeportista[] personas = new CDeportista[total];
        for (int i = 0; i < total; i++)
        {
            personas[i] = new CDeportista();
            personas[i].Leer_datos();
        }
        for (int i = 0; i < total; i++)
        {
            Console.WriteLine("\nPersona {0}:", i + 1);
            personas[i].Mostrar_datos();
        }
        Console.Write("\n");
    }
}
